print('normal file')
