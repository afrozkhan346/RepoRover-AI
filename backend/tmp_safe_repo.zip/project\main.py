print('ok')
